const handleError = (err, req, res, next) => {
  if (err.name === "CelebrateError") {
    let message = "Dados inválidos";
    try {
      // O Celebrate usa um Map. Tentamos pegar a mensagem do body, params ou query.
      const errorBody =
        err.details.get("body") ||
        err.details.get("params") ||
        err.details.get("query");
      if (errorBody && errorBody.message) {
        message = errorBody.message;
      }
    } catch (e) {
      console.log("Erro ao ler detalhes do Celebrate:", e);
    }
    return res.status(400).send({ message });
  }

  if (err.name === "ValidationError") {
    return res.status(400).send({ message: err.message });
  }
  if (err.name === "CastError") {
    return res.status(400).send({ message: "ID inválido" });
  }
  if (err.name === "DocumentNotFoundError") {
    return res.status(404).send({ message: "Recurso não encontrado" });
  }
  if (err.code === 11000) {
    return res.status(409).send({ message: "Este e-mail já está cadastrado" });
  }

  const { statusCode = 500, message } = err;
  return res.status(statusCode).send({
    message: statusCode === 500 ? "Ocorreu um erro no servidor" : message,
  });
};

module.exports = handleError;
